
//获取min-max之间的随机数
function _getRandomNum(min,max) {
    return Math.floor(Math.random()*(max-min+1)+min)
}
function _getOptions(options) {
    var optionUpdateType = options.optionUpdateType ? options.optionUpdateType : 0
    var optionUpdateMin = options.optionUpdateMin ? options.optionUpdateMin : 0
    var optionUpdateMax = options.optionUpdateMax ? options.optionUpdateMax : 100
    var optionUpdateFreq = options.optionUpdateFreq ? options.optionUpdateFreq : 3
    var optionMinValue = options.optionMinValue || options.optionMinValue === 0 ? options.optionMinValue : -Infinity
    var optionMaxValue = options.optionMaxValue ? options.optionMaxValue : Infinity
    var optionXType = options.optionXType ? options.optionXType : 1
    var optionUpdateScope = options.optionUpdateScope ? options.optionUpdateScope : 3

    return {
        optionUpdateType,
        optionUpdateMin,
        optionUpdateMax,
        optionUpdateFreq,
        optionMinValue,
        optionMaxValue,
        optionXType,
        optionUpdateScope,
    }
}

/**
 * 获取指定时间单位前的格式化时间
 * @param {number} value - 数值，表示多少个单位
 * @param {string} format - 格式化字符串，支持 YYYY, MM, DD, D, HH, mm, ss, d, dd
 *                         d: 数字星期几 (1-7, 1=周一)
 *                         dd: 中文星期几 (一、二、三、四、五、六、日)
 * @param {string} unit - 时间单位 'day'|'month'|'year'
 * @returns {string} 格式化后的时间字符串
 */
function _formatDate(value, format, unit = 'day') {
    // 创建当前日期时间对象
    const now = new Date();
    
    // 创建目标日期对象
    const targetDate = new Date(now);
    
    // 根据不同的单位调整日期
    switch (unit) {
        case 'day':
            targetDate.setDate(now.getDate() - value);
            break;
        case 'month':
            // 使用 setMonth 来处理月份增减，它会自动处理跨年和月份天数差异
            targetDate.setMonth(now.getMonth() - value);
            break;
        case 'year':
            // 使用 setFullYear 来处理年份增减
            targetDate.setFullYear(now.getFullYear() - value);
            break;
        default:
            console.warn(`Unsupported unit: ${unit}. Using 'day' as fallback.`);
            targetDate.setDate(now.getDate() - value);
    }
    
    // 获取年、月、日、时、分、秒
    const year = targetDate.getFullYear();
    const month = targetDate.getMonth() + 1; // 月份从0开始，需要+1
    const date = targetDate.getDate();
    const hours = targetDate.getHours();
    const minutes = targetDate.getMinutes();
    const seconds = targetDate.getSeconds();
    const dayOfWeek = targetDate.getDay(); // 0 (周日) 到 6 (周六)
    
    // 确保月份、日期、小时、分钟、秒为两位数（不足补0）
    const pad = (num) => num.toString().padStart(2, '0');
    const MM = pad(month);
    const DD = pad(date);
    const HH = pad(hours);
    const mm = pad(minutes);
    const ss = pad(seconds);
    
    // 计算中文星期几和数字星期几（1-7）
    const dayNumber = dayOfWeek === 0 ? 7 : dayOfWeek; // 将周日(0)映射为7
    const weekDays = ['日', '一', '二', '三', '四', '五', '六'];
    const dd = `周${weekDays[dayOfWeek]}`; // 结果如 "周一", "周二", ..., "周日"
    
    // 替换格式化字符串中的占位符
    // 注意替换顺序：先替换长的，再替换短的
    let result = format;
    result = result.replace(/YYYY/g, year);
    result = result.replace(/MM/g, MM);
    result = result.replace(/DD/g, DD);
    result = result.replace(/d{2,}/g, dd); // 先替换 dd (或更多d)
    result = result.replace(/d/g, dayNumber); // 再替换单个 d
    result = result.replace(/D/g, date); // D 表示单个数字的天（不补0）
    result = result.replace(/HH/g, HH);
    result = result.replace(/mm/g, mm);
    result = result.replace(/ss/g, ss);
    
    return result;
}


/**
 * 获取指定时间单位前的格式化时间（仅时间）
 * @param {number} value - 数值，表示多少个单位
 * @param {string} format - 格式化字符串，支持 HH, mm, ss
 * @param {string} unit - 时间单位 'hour'|'minute'|'second'
 * @returns {string} 格式化后的时间字符串
 */
function _formatTime(value, format, unit = 'hour') {
    // 创建当前时间对象
    const now = new Date();
    
    // 创建目标时间对象
    const targetTime = new Date(now);
    
    // 根据不同的单位调整时间
    switch (unit) {
        case 'hour':
            // 使用 setHours 来增加/减少小时数
            // 第二个参数传入 now.getHours() 可以保持原分钟和秒不变
            targetTime.setHours(now.getHours() - value);
            break;
        case 'minute':
            // 使用 setMinutes 来增加/减少分钟数
            targetTime.setMinutes(now.getMinutes() - value);
            break;
        case 'second':
            // 使用 setSeconds 来增加/减少秒数
            targetTime.setSeconds(now.getSeconds() - value);
            break;
        default:
            console.warn(`Unsupported unit: ${unit}. Using 'hour' as fallback.`);
            targetTime.setHours(now.getHours() - value);
    }
    
    // 获取时、分、秒
    const hours = targetTime.getHours();
    const minutes = targetTime.getMinutes();
    const seconds = targetTime.getSeconds();
    
    // 确保为两位数（不足补0）
    const pad = (num) => num.toString().padStart(2, '0');
    const HH = pad(hours);
    const mm = pad(minutes);
    const ss = pad(seconds);
    
    // 替换格式化字符串中的占位符
    let result = format;
    result = result.replace(/HH/g, HH);
    result = result.replace(/mm/g, mm);
    result = result.replace(/ss/g, ss);
    
    return result;
}


function _getXTitles(options,data) {
    var optionXType = options.optionXType
    var length = data.titles.length
    if(optionXType === 2){
        // 返回当前日期的前length个日期（格式：年-月-日）
        var res = []
        for(var i=0;i<length;i++){
            res.push(_formatDate(i,'YYYY-MM-DD','day'))
        }
        return res.reverse()

    }

    if(optionXType === 3){
        // 返回当前日期的前length个日期（格式：年-月）
        var res = []
        for(var i=0;i<length;i++){
            res.push(_formatDate(i,'YYYY-MM','month'))
        }
        return res.reverse()
    }

    if(optionXType === 4){
        // 返回当前日期的前length个日期（格式：月-日）
        var res = []
        for(var i=0;i<length;i++){
            res.push(_formatDate(i,'MM-DD','day'))
        }
        return res.reverse()
    }

    if(optionXType === 5){
        // 返回当前日期的前length个日期（格式：年）
        var date = new Date()
        var year = date.getFullYear()
        var res = []
        for(var i=0;i<length;i++){
            res.push(`${year-i}`)
        }
        return res.reverse()
    }

    if(optionXType === 6){
        // 返回当前日期的前length个日期（格式：月）
        var res = []
        for(var i=0;i<length;i++){
            res.push(_formatDate(i,'MM','month'))
        }
        return res.reverse()
    }

    if(optionXType === 7){
        // 返回当前日期的前length个日期（格式：日）
        var res = []
        for(var i=0;i<length;i++){
            res.push(_formatDate(i,'DD','day'))
        }
        return res.reverse()
    }
    if(optionXType === 7){
        // 返回当前日期的前length个日期（格式：周）
        var res = []
        for(var i=0;i<length;i++){
            res.push(_formatDate(i,'dd','day'))
        }
        return res.reverse()
    }

    if(optionXType === 8){
        // 返回当前日期的前length个日期（格式：周）
        var res = []
        for(var i=0;i<length;i++){
            res.push(_formatDate(i,'dd','day'))
        }
        return res.reverse()
    }

    if(optionXType === 9){
        // 返回当前时间的前length个时间（格式：时:分:秒）
        var res = []
        for(var i=0;i<length;i++){
            res.push(_formatTime(i,'HH:mm:ss','hour'))
        }
        return res.reverse()
    }

    if(optionXType === 10){
        // 返回当前时间的前length个时间（格式：时:分）
        var res = []
        for(var i=0;i<length;i++){
            res.push(_formatTime(i,'HH:mm','hour'))
        }
        return res.reverse()
    }

    if(optionXType === 11){
        // 返回当前时间的前length个时间（格式：分:秒）
        var res = []
        for(var i=0;i<length;i++){
            res.push(_formatTime(i,'mm:ss','minute'))
        }
        return res.reverse()
    }

    return data.titles
}

function random(options={},data,min=0,max=100) {
    // 随机数据范围在0-data之间,如果data是小数,则返回值是小数并且小数位数和data相同，否则返回值是整数
    var data = Number(data)
    max = max?max:data
    var randomNum = _getRandomNum(min,max)
    if(data%1===0){
        return Math.floor(randomNum)
    }
    const length = data.toString().split('.')[1]?data.toString().split('.')[1].length:0
    return Number((randomNum).toFixed(length))
}

function increase(options={},data,min=0,max=100) {
    // 随机增加范围在0-10之间,如果data是小数,则返回值是小数并且小数位数和data相同，否则返回值是整数
    // 增加的随机数范围在min-max之间
    var data = Number(data)
    var randomNum = _getRandomNum(min,max)
    if(data%1===0){
        return data+Math.floor(randomNum)
    }
    
    const length = data.toString().split('.')[1]?data.toString().split('.')[1].length:0
    console.log('data',data)
    console.log('length',length)
    return Number((data+randomNum).toFixed(length))
}

function decrease(options={},data,min=0,max=100) {
    // 随机减少范围在0-10之间,如果data是小数,则返回值是小数并且小数位数和data相同，否则返回值是整数
    var data = Number(data)
    var randomNum = _getRandomNum(min,max)
    if(data%1===0){
        return data-Math.floor(randomNum)
    }
    const length = data.toString().split('.')[1]?data.toString().split('.')[1].length:0
    return Number((data-randomNum).toFixed(length))
}

function increaseDecrease(options={},data,min=0,max=100) {
    // 随机加减范围在0-10之间,如果data是小数,则返回值是小数并且小数位数和data相同，否则返回值是整数
    // 增加的随机数范围在min-max之间
    var data = Number(data)
    var randomNum = _getRandomNum(min,max)
    // 随机*-1,增加或减少随机数的正负
    randomNum = Math.random()>0.5?randomNum:-randomNum
    if(data%1===0){
        return data+Math.floor(randomNum)
    }
    const length = data.toString().split('.')[1]?data.toString().split('.')[1].length:0
    return Number((data+randomNum).toFixed(length))
}



function highNum(options,data) {
    console.log('options',options)
    console.log('data',data)
    var options = _getOptions(options)
    var res = data

    if(options.optionUpdateType === 1){
        res = increase(options,res,options.optionUpdateMax,options.optionUpdateMin)
        if(res>options.optionMaxValue){
            res = options.optionMaxValue
        }
    }
    if(options.optionUpdateType === 2){
        res = decrease(options,res,options.optionUpdateMax,options.optionUpdateMin)
        if(res<options.optionMinValue){
            res = options.optionMinValue
        }
    }
    if(options.optionUpdateType === 3){
        res = increaseDecrease(options,res,options.optionUpdateMax,options.optionUpdateMin)
        if(res>options.optionMaxValue){
            res = options.optionMaxValue
        }
        if(res<options.optionMinValue){
            res = options.optionMinValue
        }
    }
    if(options.optionUpdateType === 4){
        res = random(options,res,options.optionUpdateMin,options.optionUpdateMax)
        if(res>options.optionMaxValue){
            res = options.optionMaxValue
        }
        if(res<options.optionMinValue){
            res = options.optionMinValue
        }
    }

    return res
}

function randomLine(options={},data,min=0,max=0) {
    max = max?max:Math.max(...data.values.map(item=>Math.max(...item.data)))
    const res = data
    var options = _getOptions(options)
    //     optionXType
// optionUpdateScope
    if(res.values[0].data[0]%1===0){
        res.values.forEach(item=>{
            var randomNum = _getRandomNum(min,max)
            if(options.optionUpdateScope==3){
                item.data[item.data.length-1] = Math.floor(randomNum)
            }
            if(options.optionUpdateScope==2){
                item.data[0] = Math.floor(randomNum)
            }
            if(options.optionUpdateScope==1){
                item.data.forEach((v,i)=>{
                    var randomNum = _getRandomNum(min,max)
                    item.data[i] = Math.floor(randomNum)
                })
            }
        })
        return res
    }
    res.values.forEach(item=>{
        var randomNum = _getRandomNum(min,max)
        if(options.optionUpdateScope==3){
            const length = item.data[item.data.length-1].toString().split('.')[1] ? item.data[item.data.length-1].toString().split('.')[1].length : 0
            item.data[item.data.length-1] = Number((randomNum).toFixed(length))
        }
        if(options.optionUpdateScope==2){
             const length = item.data[item.data.length-1].toString().split('.')[1] ? item.data[item.data.length-1].toString().split('.')[1].length : 0
            item.data[0] = Number((randomNum).toFixed(length))
        }
        if(options.optionUpdateScope==1){
            item.data.forEach((v,i)=>{
                var randomNum = _getRandomNum(min,max)
                const length = item.data[i].toString().split('.')[1] ? item.data[i].toString().split('.')[1].length : 0
                item.data[i] = Number((randomNum).toFixed(length))
            })
        }
        
    })




    return res 
}


function increaseLine(options={},data,min=0,max=100) {
    max = max?max:(Math.max(...data.values.map(item=>Math.max(...item.data)))/1000)
    const res = data
    var options = _getOptions(options)
    if(res.values[0].data[0]%1===0){
        res.values.forEach(item=>{
            var randomNum = _getRandomNum(min,max)
            
            if(options.optionUpdateScope==3){
                item.data[item.data.length-1] += Math.floor(randomNum)
            }
            if(options.optionUpdateScope==2){
                item.data[0] += Math.floor(randomNum)
            }
            if(options.optionUpdateScope==1){
                item.data.forEach((v,i)=>{
                    var randomNum = _getRandomNum(min,max)
                    item.data[i] += Math.floor(randomNum)
                })
            }
        })
        return res
    }
    res.values.forEach(item=>{
        var randomNum = _getRandomNum(min,max)
        
        if(options.optionUpdateScope==3){
            const length = item.data[item.data.length-1].toString().split('.')[1] ? item.data[item.data.length-1].toString().split('.')[1].length : 0
            item.data[item.data.length-1] += Number((randomNum).toFixed(length))
        }
        if(options.optionUpdateScope==2){
            const length = item.data[0].toString().split('.')[1] ? item.data[0].toString().split('.')[1].length : 0
            item.data[0] += Number((randomNum).toFixed(length))
        }
        if(options.optionUpdateScope==1){
            item.data.forEach((v,i)=>{
                var randomNum = _getRandomNum(min,max)
                const length = item.data[i].toString().split('.')[1] ? item.data[i].toString().split('.')[1].length : 0
                item.data[i] += Number((randomNum).toFixed(length))
            })
        }
    })
    return res 
}

function decreaseLine(options={},data,min=0,max=100) {
    max = max?max:(Math.max(...data.values.map(item=>Math.max(...item.data)))/1000)
    const res = data
    var options = _getOptions(options)
    if(res.values[0].data[0]%1===0){
        res.values.forEach(item=>{
            var randomNum = _getRandomNum(min,max)
            
            if(options.optionUpdateScope==3){
                item.data[item.data.length-1] -= Math.floor(randomNum)
            }
            if(options.optionUpdateScope==2){
                item.data[0] -= Math.floor(randomNum)
            }
            if(options.optionUpdateScope==1){
                item.data.forEach((v,i)=>{
                    var randomNum = _getRandomNum(min,max)
                    item.data[i] -= Math.floor(randomNum)
                })
            }
        })
        return res
    }
    res.values.forEach(item=>{
        var randomNum = _getRandomNum(min,max)
        if(options.optionUpdateScope==3){
            const length = item.data[item.data.length-1].toString().split('.')[1] ? item.data[item.data.length-1].toString().split('.')[1].length : 0
            item.data[item.data.length-1] -= Number((randomNum).toFixed(length))
        }
        if(options.optionUpdateScope==2){
            const length = item.data[0].toString().split('.')[1] ? item.data[0].toString().split('.')[1].length : 0
            item.data[0] -= Number((randomNum).toFixed(length))
        }
        if(options.optionUpdateScope==1){
            item.data.forEach((v,i)=>{
                var randomNum = _getRandomNum(min,max)
                const length = item.data[i].toString().split('.')[1] ? item.data[i].toString().split('.')[1].length : 0
                item.data[i] -= Number((randomNum).toFixed(length))
            })
        }
    })
    return res 
}

function increaseDecreaseLine(options={},data,min=0,max=100) {
    max = max?max:(Math.max(...data.values.map(item=>Math.max(...item.data)))/1000)
    const res = data
    var options = _getOptions(options)
    if(res.values[0].data[0]%1===0){
        res.values.forEach(item=>{
            var randomNum = _getRandomNum(min,max)
            randomNum = Math.random()>0.5?randomNum:-randomNum
            if(options.optionUpdateScope==3){
                item.data[item.data.length-1] += Math.floor(randomNum)
            }
            if(options.optionUpdateScope==2){
                item.data[0] += Math.floor(randomNum)
            }
            if(options.optionUpdateScope==1){
                item.data.forEach((v,i)=>{
                    var randomNum = _getRandomNum(min,max)
                    randomNum = Math.random()>0.5?randomNum:-randomNum
                    item.data[i] += Math.floor(randomNum)
                })
            }
        })
        return res
    }
    res.values.forEach(item=>{
        var randomNum = _getRandomNum(min,max)
        randomNum = Math.random()>0.5?randomNum:-randomNum
        // item.data[item.data.length-1] += Number((item.data[item.data.length-1]+randomNum).toFixed(item.data[item.data.length-1].toString().split('.')[1].length))
        if(options.optionUpdateScope==3){
            const length = item.data[item.data.length-1].toString().split('.')[1] ? item.data[item.data.length-1].toString().split('.')[1].length : 0
            item.data[item.data.length-1] += Number((randomNum).toFixed(length))
        }
        if(options.optionUpdateScope==2){
            const length = item.data[0].toString().split('.')[1] ? item.data[0].toString().split('.')[1].length : 0
            item.data[0] += Number((randomNum).toFixed(length))
        }
        if(options.optionUpdateScope==1){
            item.data.forEach((v,i)=>{
                var randomNum = _getRandomNum(min,max)
                randomNum = Math.random()>0.5?randomNum:-randomNum
                const length = item.data[i].toString().split('.')[1] ? item.data[i].toString().split('.')[1].length : 0
                item.data[i] += Number((randomNum).toFixed(length))
            })
        }
    })
    return res 
}

function highLine(options,data) {

    var options = _getOptions(options)
    var res = data
    if(options.optionUpdateType === 1){
        res = increaseLine(options,res,options.optionUpdateMax,options.optionUpdateMin)
        res.values.forEach(item=>{
            item.data.forEach((v,i)=>{
                if(v>options.optionMaxValue){
                    item.data[i] = options.optionMaxValue
                }
            })
        })
        
    }
    if(options.optionUpdateType === 2){
        res = decreaseLine(options,res,options.optionUpdateMax,options.optionUpdateMin)
        // if(res<options.optionMinValue){
        //     res = options.optionMinValue
        // }
        res.values.forEach(item=>{
            item.data.forEach((v,i)=>{
                console.log('v',v)
                console.log('options.optionMinValue',options.optionMinValue)
                if(v<options.optionMinValue){
                    item.data[i] = options.optionMinValue
                }
            })
        })
    }
    if(options.optionUpdateType === 3){
        res = increaseDecreaseLine(options,res,options.optionUpdateMax,options.optionUpdateMin)
        
        res.values.forEach(item=>{
            item.data.forEach((v,i)=>{
                if(v>options.optionMaxValue){
                    item.data[i] = options.optionMaxValue
                }
                if(v<options.optionMinValue){
                    item.data[i] = options.optionMinValue
                }
            })
        })
    }
    if(options.optionUpdateType === 4){
        res = randomLine(options,res,options.optionUpdateMin,options.optionUpdateMax)
        res.values.forEach(item=>{
            item.data.forEach((v,i)=>{
                if(v>options.optionMaxValue){
                    item.data[i] = options.optionMaxValue
                }
                if(v<options.optionMinValue){
                    item.data[i] = options.optionMinValue
                }
            })
        })
    }

    res.titles = _getXTitles(options,res)

    return res
}



function randomBar(options={},data,min=0,max=0) {
    max = max?max:Math.max(...data.values.data)
    const res = data
    var options = _getOptions(options)
    if(res.values.data[0]%1===0){
        var randomNum = _getRandomNum(min,max)
        if(options.optionUpdateScope==3){
            res.values.data[res.values.data.length-1] = Math.floor(randomNum)
        }
        if(options.optionUpdateScope==2){
            res.values.data[0] = Math.floor(randomNum)
        }
        if(options.optionUpdateScope==1){
            res.values.data.forEach((v,i)=>{
                var randomNum = _getRandomNum(min,max)
                res.values.data[i] = Math.floor(randomNum)
            })
        }
        return res
    }
    var randomNum = _getRandomNum(min,max)
    if(options.optionUpdateScope==3){
        const length = res.values.data[res.values.data.length-1].toString().split('.')[1] ? res.values.data[res.values.data.length-1].toString().split('.')[1].length : 0
        res.values.data[res.values.data.length-1] = Number((randomNum).toFixed(length))
    }
    if(options.optionUpdateScope==2){
        const length = res.values.data[0].toString().split('.')[1] ? res.values.data[0].toString().split('.')[1].length : 0
        res.values.data[0] = Number((randomNum).toFixed(length))
    }
    if(options.optionUpdateScope==1){
        res.values.data.forEach((v,i)=>{
            var randomNum = _getRandomNum(min,max)
            const length = res.values.data[i].toString().split('.')[1] ? res.values.data[i].toString().split('.')[1].length : 0
            res.values.data[i] = Number((randomNum).toFixed(length))
        })
    }
    return res 
}


function increaseBar(options={},data,min=0,max=100) {
    max = max?max:Math.max(...data.values.data)
    const res = data
    var options = _getOptions(options)
    if(res.values.data[0]%1===0){
        var randomNum = _getRandomNum(min,max)
        if(options.optionUpdateScope==3){
            res.values.data[res.values.data.length-1] += Math.floor(randomNum)
        }
        if(options.optionUpdateScope==2){
            res.values.data[0] += Math.floor(randomNum)
        }
        if(options.optionUpdateScope==1){
            res.values.data.forEach((v,i)=>{
                var randomNum = _getRandomNum(min,max)
                res.values.data[i] += Math.floor(randomNum)
            })
        }
        return res
    }
    if(options.optionUpdateScope==3){
        const length = res.values.data[res.values.data.length-1].toString().split('.')[1] ? res.values.data[res.values.data.length-1].toString().split('.')[1].length : 0
        res.values.data[res.values.data.length-1] += Number((randomNum).toFixed(length))
    }
    if(options.optionUpdateScope==2){
        const length = res.values.data[0].toString().split('.')[1] ? res.values.data[0].toString().split('.')[1].length : 0
        res.values.data[0] += Number((randomNum).toFixed(length))
    }
    if(options.optionUpdateScope==1){
        res.values.data.forEach((v,i)=>{
            var randomNum = _getRandomNum(min,max)
            const length = res.values.data[i].toString().split('.')[1] ? res.values.data[i].toString().split('.')[1].length : 0
            res.values.data[i] += Number((randomNum).toFixed(length))
        })
    }
    return res 
}

function decreaseBar(options={},data,min=0,max=100) {
    max = max?max:Math.max(...data.values.data)
    const res = data
    var options = _getOptions(options)
    if(res.values.data[0]%1===0){
        var randomNum = _getRandomNum(min,max)
        if(options.optionUpdateScope==3){
            res.values.data[res.values.data.length-1] -= Math.floor(randomNum)
        }
        if(options.optionUpdateScope==2){
            res.values.data[0] -= Math.floor(randomNum)
        }
        if(options.optionUpdateScope==1){
            res.values.data.forEach((v,i)=>{
                var randomNum = _getRandomNum(min,max)
                res.values.data[i] -= Math.floor(randomNum)
            })
        }
        return res
    }
    var randomNum = _getRandomNum(min,max)
    if(options.optionUpdateScope==3){
        const length = res.values.data[res.values.data.length-1].toString().split('.')[1] ? res.values.data[res.values.data.length-1].toString().split('.')[1].length : 0
        res.values.data[res.values.data.length-1] -= Number((randomNum).toFixed(length))
    }
    if(options.optionUpdateScope==2){
        const length = res.values.data[0].toString().split('.')[1] ? res.values.data[0].toString().split('.')[1].length : 0
        res.values.data[0] -= Number((randomNum).toFixed(length))
    }
    if(options.optionUpdateScope==1){
        res.values.data.forEach((v,i)=>{
            var randomNum = _getRandomNum(min,max)
            const length = res.values.data[i].toString().split('.')[1] ? res.values.data[i].toString().split('.')[1].length : 0
            res.values.data[i] -= Number((randomNum).toFixed(length))
        })
    }
    return res 
}

function increaseDecreaseBar(options={},data,min=0,max=100) {
    max = max?max:Math.max(...data.values.data)
    const res = data
    var options = _getOptions(options)
    if(res.values.data[0]%1===0){
        var randomNum = _getRandomNum(min,max)
        randomNum = Math.random()>0.5?randomNum:-randomNum
        if(options.optionUpdateScope==3){
            res.values.data[res.values.data.length-1] += Math.floor(randomNum)
        }
        if(options.optionUpdateScope==2){
            res.values.data[0] += Math.floor(randomNum)
        }
        if(options.optionUpdateScope==1){
            res.values.data.forEach((v,i)=>{
                var randomNum = _getRandomNum(min,max)
                randomNum = Math.random()>0.5?randomNum:-randomNum
                res.values.data[i] += Math.floor(randomNum)
            })
        }
        return res
    }
    var randomNum = _getRandomNum(min,max)
    randomNum = Math.random()>0.5?randomNum:-randomNum
    // item.data[item.data.length-1] += Number((item.data[item.data.length-1]+randomNum).toFixed(item.data[item.data.length-1].toString().split('.')[1].length))
    if(options.optionUpdateScope==3){
        res.values.data[res.values.data.length-1] += Number((res.values.data[res.values.data.length-1]+randomNum).toFixed(res.values.data[res.values.data.length-1].toString().split('.')[1].length))
    }
    if(options.optionUpdateScope==2){
        res.values.data[0] += Number((randomNum).toFixed(res.values.data[0].toString().split('.')[1].length))
    }
    if(options.optionUpdateScope==1){
        res.values.data.forEach((v,i)=>{
            var randomNum = _getRandomNum(min,max)
            randomNum = Math.random()>0.5?randomNum:-randomNum
            res.values.data[i] += Number((randomNum).toFixed(res.values.data[i].toString().split('.')[1].length))
        })
    }
    return res 
}

function highBar(options,data) {

    var options = _getOptions(options)
    var res = data
    if(options.optionUpdateType === 1){
        res = increaseBar(options,res,options.optionUpdateMax,options.optionUpdateMin)
        res.values.data.forEach((v,i)=>{
            if(v>options.optionMaxValue){
                res.values.data[i] = options.optionMaxValue
            }
        })
        
    }
    if(options.optionUpdateType === 2){
        res = decreaseBar(options,res,options.optionUpdateMax,options.optionUpdateMin)
        res.values.data.forEach((v,i)=>{
            if(v<options.optionMinValue){
                res.values.data[i] = options.optionMinValue
            }
        })
    }
    if(options.optionUpdateType === 3){
        res = increaseDecreaseBar(options,res,options.optionUpdateMax,options.optionUpdateMin)
        
        res.values.data.forEach((v,i)=>{
            if(v>options.optionMaxValue){
                res.values.data[i] = options.optionMaxValue
            }
            if(v<options.optionMinValue){
                res.values.data[i] = options.optionMinValue
            }
        })
    }
    if(options.optionUpdateType === 4){
        res = randomBar(options,res,options.optionUpdateMin,options.optionUpdateMax)
        res.values.data.forEach((v,i)=>{
            if(v>options.optionMaxValue){
                res.values.data[i] = options.optionMaxValue
            }
            if(v<options.optionMinValue){
                res.values.data[i] = options.optionMinValue
            }
        })
    }

    res.titles = _getXTitles(options,res)

    return res
}

// ---------------------------------------------

function randomPie(options,data) {
    var options = _getOptions(options)
    var res = data
    if(res[0].value%1===0){
        res.forEach((item,i)=>{
            var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
            item.value = Math.floor(randomNum)
        })
        return res
    }
    res.forEach((item,i)=>{
        var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
        item.value = Number((randomNum).toFixed(item.value.toString().split('.')[1].length))
    })
    return res
}

function increasePie(options,data) {
    var options = _getOptions(options)
    var res = data
    if(res[0].value%1===0){
        res.forEach((item,i)=>{
            var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
            item.value += Math.floor(randomNum)
        })
        return res
    }
    res.forEach((item,i)=>{
        var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
        const length = item.value.toString().split('.')[1] ? item.value.toString().split('.')[1].length : 0
        item.value += Number((randomNum).toFixed(length))
    })
    return res
}

function decreasePie(options,data) {
    var options = _getOptions(options)
    var res = data
    if(res[0].value%1===0){
        res.forEach((item,i)=>{
            var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
            item.value -= Math.floor(randomNum)
        })
        return res
    }
    res.forEach((item,i)=>{
        var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
        const length = item.value.toString().split('.')[1] ? item.value.toString().split('.')[1].length : 0
        item.value -= Number((randomNum).toFixed(length))
    })
    return res
}

function increaseDecreasePie(options,data) {
    var options = _getOptions(options)
    var res = data
    if(res[0].value%1===0){
        res.forEach((item,i)=>{
            var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
            randomNum = Math.random()>0.5?randomNum:-randomNum
            item.value += Math.floor(randomNum)
        })
        return res
    }
    res.forEach((item,i)=>{
        var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
        randomNum = Math.random()>0.5?randomNum:-randomNum
        const length = item.value.toString().split('.')[1] ? item.value.toString().split('.')[1].length : 0
        item.value += Number((randomNum).toFixed(length))
    })
    return res
}

function highPie(options,data) {
    var options = _getOptions(options)
    var res = data
  
    if(options.optionUpdateType === 1){
        res = increasePie(options,res,options.optionUpdateMax,options.optionUpdateMin)
    }
    if(options.optionUpdateType === 2){
        res = decreasePie(options,res,options.optionUpdateMax,options.optionUpdateMin)
    }
    if(options.optionUpdateType === 3){
        res = increaseDecreasePie(options,res,options.optionUpdateMax,options.optionUpdateMin)
        
    }
    if(options.optionUpdateType === 4){
        res = randomPie(options,res,options.optionUpdateMin,options.optionUpdateMax)
    }

    res.forEach((item,i)=>{
        if(item.value>options.optionMaxValue){
            item.value = options.optionMaxValue
        }
        if(item.value<options.optionMinValue){
            item.value = options.optionMinValue
        }
    })

    return res
}

// ---------------------------------------------
function randomBubMap(options,data) {
    var options = _getOptions(options)
    var res = data
    if(res[0].value[2]%1===0){
        res.forEach((item,i)=>{
            var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
            item.value[2] = Math.floor(randomNum)
        })
        return res
    }
    res.forEach((item,i)=>{
        var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
        const length = item.value[2].toString().split('.')[1] ? item.value[2].toString().split('.')[1].length : 0
        item.value[2] = Number((randomNum).toFixed(length))
    })
    return res
}

function increaseBubMap(options,data) {
    var options = _getOptions(options)
    var res = data
    if(res[0].value[2]%1===0){
        res.forEach((item,i)=>{
            var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
            item.value[2] += Math.floor(randomNum)
        })
        return res
    }
    res.forEach((item,i)=>{
        var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
        const length = item.value[2].toString().split('.')[1] ? item.value[2].toString().split('.')[1].length : 0
        item.value[2] += Number((randomNum).toFixed(length))
    })
    return res
}

function decreaseBubMap(options,data) {
    var options = _getOptions(options)
    var res = data
    if(res[0].value[2]%1===0){
        res.forEach((item,i)=>{
            var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
            item.value[2] -= Math.floor(randomNum)
        })
        return res
    }
    res.forEach((item,i)=>{
        var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
        randomNum = Math.random()>0.5?randomNum:-randomNum
        const length = item.value[2].toString().split('.')[1] ? item.value[2].toString().split('.')[1].length : 0
        item.value[2] -= Number((randomNum).toFixed(length))
    })
    return res
}

function increaseDecreaseBubMap(options,data) {
    var options = _getOptions(options)
    var res = data
    if(res[0].value[2]%1===0){
        res.forEach((item,i)=>{
            var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
            randomNum = Math.random()>0.5?randomNum:-randomNum
            item.value[2] += Math.floor(randomNum)
        })
        return res
    }
    res.forEach((item,i)=>{
        var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
        randomNum = Math.random()>0.5?randomNum:-randomNum
        const length = item.value[2].toString().split('.')[1] ? item.value[2].toString().split('.')[1].length : 0
        item.value[2] += Number((randomNum).toFixed(length))
    })
    return res
}

function highBubMap(options,data) {
    var options = _getOptions(options)
    var res = data
  
    if(options.optionUpdateType === 1){
        res = increaseBubMap(options,res,options.optionUpdateMax,options.optionUpdateMin)
    }
    if(options.optionUpdateType === 2){
        res = decreaseBubMap(options,res,options.optionUpdateMax,options.optionUpdateMin)
    }
    if(options.optionUpdateType === 3){
        res = increaseDecreaseBubMap(options,res,options.optionUpdateMax,options.optionUpdateMin)
        
    }
    if(options.optionUpdateType === 4){
        res = randomBubMap(options,res,options.optionUpdateMin,options.optionUpdateMax)
    }

    res.forEach((item,i)=>{
        if(item.value[2]>options.optionMaxValue){
            item.value[2] = options.optionMaxValue
        }
        if(item.value[2]<options.optionMinValue){
            item.value[2] = options.optionMinValue
        }
    })

    return res
}

// -----------------------------
function _updateValueRecursively(arr, modifyFn) {
  // 使用普通 for 循环替代 forEach 和箭头函数
  for (var i = 0; i < arr.length; i++) {
    var item = arr[i];

    // 修改当前节点的 value
    if (item.value !== undefined) {
      item.value = modifyFn(item.value);
    }

    // 如果有 children，递归处理
    if (item.children && Array.isArray(item.children) && item.children.length > 0) {
      _updateValueRecursively(item.children, modifyFn);
    }
  }
}
function randomTree(options,data) {
    var options = _getOptions(options)
    var res = data

    if(res[0].value%1===0){
        _updateValueRecursively(res, function(value) {
            var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
            return Math.floor(randomNum);
        });
        return res
    }

    _updateValueRecursively(res, function(value) {
        var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
        const length = value.toString().split('.')[1] ? value.toString().split('.')[1].length : 0
        return Number((randomNum).toFixed(length));
    });
    return res
}

function increaseTree(options,data) {
    var options = _getOptions(options)
    var res = data
    if(res[0].value%1===0){
        _updateValueRecursively(res, function(value) {
            var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
            return value + Math.floor(randomNum);
        });
        return res
    }
    _updateValueRecursively(res, function(value) {
        var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
        const length = value.toString().split('.')[1] ? value.toString().split('.')[1].length : 0
        return value + Number((randomNum).toFixed(length));
    });
    return res
}

function decreaseTree(options,data) {
    var options = _getOptions(options)
    var res = data
    if(res[0].value%1===0){
        _updateValueRecursively(res, function(value) {
            var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
            return value - Math.floor(randomNum);
        });
        return res
    }
    _updateValueRecursively(res, function(value) {
        var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
        const length = value.toString().split('.')[1] ? value.toString().split('.')[1].length : 0
        return value - Number((randomNum).toFixed(length));
    });
    return res
}

function increaseDecreaseTree(options,data) {
    var options = _getOptions(options)
    var res = data
    if(res[0].value%1===0){
        _updateValueRecursively(res, function(value) {
            var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
            randomNum = Math.random()>0.5?randomNum:-randomNum
            return value + Math.floor(randomNum);
        });
        return res
    }
    _updateValueRecursively(res, function(value) {
        var randomNum = _getRandomNum(options.optionUpdateMin,options.optionUpdateMax)
        randomNum = Math.random()>0.5?randomNum:-randomNum
        const length = value.toString().split('.')[1] ? value.toString().split('.')[1].length : 0
        return value + Number((randomNum).toFixed(length));
    });
    return res
}

function highTree(options,data) {
    var options = _getOptions(options)
    var res = data
  
    if(options.optionUpdateType === 1){
        res = increaseTree(options,res,options.optionUpdateMax,options.optionUpdateMin)
    }
    if(options.optionUpdateType === 2){
        res = decreaseTree(options,res,options.optionUpdateMax,options.optionUpdateMin)
    }
    if(options.optionUpdateType === 3){
        res = increaseDecreaseTree(options,res,options.optionUpdateMax,options.optionUpdateMin)
        
    }
    if(options.optionUpdateType === 4){
        res = randomTree(options,res,options.optionUpdateMin,options.optionUpdateMax)
    }

    _updateValueRecursively(res, function(value) {
        if(value>options.optionMaxValue){
            return options.optionMaxValue
        }
        if(value<options.optionMinValue){
            return options.optionMinValue
        }
        return value
    });

    return res
}
// ---------------------------------------------

function randomRadar(options={},data,min=0,max=0) {
    max = max?max:Math.max(...data.values.map(item=>Math.max(...item.value)))
    const res = data
    var options = _getOptions(options)
    if(res.values[0].value[0]%1===0){
        res.values.forEach(item=>{
            item.value.forEach((v,i)=>{
                var randomNum = _getRandomNum(min,max)
                item.value[i] = Math.floor(randomNum)
            })
        })
        return res
    }
    res.values.forEach(item=>{
        item.value.forEach((v,i)=>{
            var randomNum = _getRandomNum(min,max)
            const length = item.value[i].toString().split('.')[1] ? item.value[i].toString().split('.')[1].length : 0
            item.value[i] = Number((randomNum).toFixed(length))
        })
    })
    return res 
}


function increaseRadar(options={},data,min=0,max=100) {
    max = max?max:Math.max(...data.values.map(item=>Math.max(...item.value)))
    const res = data
    var options = _getOptions(options)
    if(res.values[0].value[0]%1===0){
        res.values.forEach(item=>{
            item.value.forEach((v,i)=>{
                var randomNum = _getRandomNum(min,max)
                item.value[i] += Math.floor(randomNum)
            })
        })
        return res
    }
    res.values.forEach(item=>{
        item.value.forEach((v,i)=>{
            var randomNum = _getRandomNum(min,max)
            const length = item.value[i].toString().split('.')[1] ? item.value[i].toString().split('.')[1].length : 0
            item.value[i] += Number((randomNum).toFixed(length))
        })
    })
    return res 
}

function decreaseRadar(options={},data,min=0,max=100) {
    max = max?max:Math.max(...data.values.map(item=>Math.max(...item.value)))
    const res = data
    var options = _getOptions(options)
    if(res.values[0].value[0]%1===0){
        res.values.forEach(item=>{
            item.value.forEach((v,i)=>{
                var randomNum = _getRandomNum(min,max)
                item.value[i] -= Math.floor(randomNum)
            })
        })
        return res
    }
    res.values.forEach(item=>{
        item.value.forEach((v,i)=>{
            var randomNum = _getRandomNum(min,max)
            const length = item.value[i].toString().split('.')[1] ? item.value[i].toString().split('.')[1].length : 0
            item.value[i] -= Number((randomNum).toFixed(length))
        })
    })
    return res 
}

function increaseDecreaseRadar(options={},data,min=0,max=100) {
    max = max?max:Math.max(...data.values.map(item=>Math.max(...item.value)))
    const res = data
    var options = _getOptions(options)
    if(res.values[0].value[0]%1===0){
        res.values.forEach(item=>{
            item.value.forEach((v,i)=>{
                var randomNum = _getRandomNum(min,max)
                randomNum = Math.random()>0.5?randomNum:-randomNum
                item.value[i] += Math.floor(randomNum)
            })
        })
        return res
    }
    res.values.forEach(item=>{
        item.value.forEach((v,i)=>{
            var randomNum = _getRandomNum(min,max)
            randomNum = Math.random()>0.5?randomNum:-randomNum
            const length = item.value[i].toString().split('.')[1] ? item.value[i].toString().split('.')[1].length : 0
            item.value[i] += Number((randomNum).toFixed(length))
        })
    })
    return res 
}

function highRadar(options,data) {

    var options = _getOptions(options)
    var res = data
    if(options.optionUpdateType === 1){
        res = increaseRadar(options,res,options.optionUpdateMax,options.optionUpdateMin)
        res.values.forEach(item=>{
            item.value.forEach((v,i)=>{
                if(v>options.optionMaxValue){
                    item.value[i] = options.optionMaxValue
                }
            })
        })
        
    }
    if(options.optionUpdateType === 2){
        res = decreaseRadar(options,res,options.optionUpdateMax,options.optionUpdateMin)
        // if(res<options.optionMinValue){
        //     res = options.optionMinValue
        // }
        res.values.forEach(item=>{
            item.value.forEach((v,i)=>{
                if(v<options.optionMinValue){
                    item.value[i] = options.optionMinValue
                }
            })
        })
    }
    if(options.optionUpdateType === 3){
        res = increaseDecreaseRadar(options,res,options.optionUpdateMax,options.optionUpdateMin)
        
        res.values.forEach(item=>{
            item.value.forEach((v,i)=>{
                if(v>options.optionMaxValue){
                    item.value[i] = options.optionMaxValue
                }
                if(v<options.optionMinValue){
                    item.value[i] = options.optionMinValue
                }
            })
        })
    }
    if(options.optionUpdateType === 4){
        res = randomRadar(options,res,options.optionUpdateMin,options.optionUpdateMax)
        res.values.forEach(item=>{
            item.value.forEach((v,i)=>{
                if(v>options.optionMaxValue){
                    item.value[i] = options.optionMaxValue
                }
                if(v<options.optionMinValue){
                    item.value[i] = options.optionMinValue
                }
            })
        })
    }

    return res
}
// ---------------------------------------------







var dsDataUpdatesFuns = {
    'none':function(data){return data},
    'random':random,
    'increase':increase,
    'decrease':decrease,
    'increaseDecrease':increaseDecrease,
    'highNum':highNum,
    'randomLine':randomLine,
    'increaseLine':increaseLine,
    'decreaseLine':decreaseLine,
    'increaseDecreaseLine':increaseDecreaseLine,
    'highLine':highLine,
    'randomBar':randomBar,
    'increaseBar':increaseBar,
    'decreaseBar':decreaseBar,
    'increaseDecreaseBar':increaseDecreaseBar,
    'highBar':highBar,
    'randomPie':randomPie,
    'increasePie':increasePie,
    'decreasePie':decreasePie,
    'increaseDecreasePie':increaseDecreasePie,
    'highPie':highPie,
    'randomBubMap':randomBubMap,
    'increaseBubMap':increaseBubMap,
    'decreaseBubMap':decreaseBubMap,
    'increaseDecreaseBubMap':increaseDecreaseBubMap,
    'highBubMap':highBubMap,
    'randomTree':randomTree,
    'increaseTree':increaseTree,
    'decreaseTree':decreaseTree,
    'increaseDecreaseTree':increaseDecreaseTree,
    'highTree':highTree,
    'randomRadar':randomRadar,
    'increaseRadar':increaseRadar,
    'decreaseRadar':decreaseRadar,
    'increaseDecreaseRadar':increaseDecreaseRadar,
    'highRadar':highRadar,
}


var noneOption =  {label:'无',value:'none',disabled:false,grade:1}
var randomOption =  {label:'随机数据',value:'random',disabled:false,grade:2}
var increaseOption =  {label:'随机增加',value:'increase',disabled:false,grade:2}
var decreaseOption =  {label:'随机减少',value:'decrease',disabled:false,grade:2}
var increaseDecreaseOption =  {label:'随机加减',value:'increaseDecrease',disabled:false,grade:2}
var highNumOption =  {label:'自定义',value:'highNum',disabled:false,grade:2}
var randomLineOption =  {label:'随机数据',value:'randomLine',disabled:false,grade:2}
var increaseLineOption =  {label:'随机增加',value:'increaseLine',disabled:false,grade:2}
var decreaseLineOption =  {label:'随机减少',value:'decreaseLine',disabled:false,grade:2}
var increaseDecreaseLineOption =  {label:'随机加减',value:'increaseDecreaseLine',disabled:false,grade:2}
var highLineOption =  {label:'自定义',value:'highLine',disabled:false,grade:2}
var randomPieOption =  {label:'随机数据',value:'randomPie',disabled:false,grade:2}
var increasePieOption =  {label:'随机增加',value:'increasePie',disabled:false,grade:2}
var decreasePieOption =  {label:'随机减少',value:'decreasePie',disabled:false,grade:2}
var increaseDecreasePieOption =  {label:'随机加减',value:'increaseDecreasePie',disabled:false,grade:2}
var highPieOption =  {label:'自定义',value:'highPie',disabled:false,grade:2}
var randomBubMapOption =  {label:'随机数据',value:'randomBubMap',disabled:false,grade:2}
var increaseBubMapOption =  {label:'随机增加',value:'increaseBubMap',disabled:false,grade:2}
var decreaseBubMapOption =  {label:'随机减少',value:'decreaseBubMap',disabled:false,grade:2}
var increaseDecreaseBubMapOption =  {label:'随机加减',value:'increaseDecreaseBubMap',disabled:false,grade:2}
var highBubMapOption =  {label:'自定义',value:'highBubMap',disabled:false,grade:2}
var randomTreeOption =  {label:'随机数据',value:'randomTree',disabled:false,grade:2}
var increaseTreeOption =  {label:'随机增加',value:'increaseTree',disabled:false,grade:2}
var decreaseTreeOption =  {label:'随机减少',value:'decreaseTree',disabled:false,grade:2}
var increaseDecreaseTreeOption =  {label:'随机加减',value:'increaseDecreaseTree',disabled:false,grade:2}
var highTreeOption =  {label:'自定义',value:'highTree',disabled:false,grade:2}
var randomRadarOption =  {label:'随机数据',value:'randomRadar',disabled:false,grade:2}
var increaseRadarOption =  {label:'随机增加',value:'increaseRadar',disabled:false,grade:2}
var decreaseRadarOption =  {label:'随机减少',value:'decreaseRadar',disabled:false,grade:2}
var increaseDecreaseRadarOption =  {label:'随机加减',value:'increaseDecreaseRadar',disabled:false,grade:2}
var highRadarOption =  {label:'自定义',value:'highRadar',disabled:false,grade:2}
var randomBarOption =  {label:'随机数据',value:'randomBar',disabled:false,grade:2}
var increaseBarOption =  {label:'随机增加',value:'increaseBar',disabled:false,grade:2}
var decreaseBarOption =  {label:'随机减少',value:'decreaseBar',disabled:false,grade:2}
var increaseDecreaseBarOption =  {label:'随机加减',value:'increaseDecreaseBar',disabled:false,grade:2}
var highBarOption =  {label:'自定义',value:'highBar',disabled:false,grade:2}



var dsDataUpdates = {
    'num':[noneOption,randomOption,increaseOption,decreaseOption,increaseDecreaseOption,highNumOption],
    'number':[noneOption,randomOption,increaseOption,decreaseOption,increaseDecreaseOption,highNumOption],
    'percentPond':[noneOption,randomOption,increaseOption,decreaseOption,increaseDecreaseOption,highNumOption],
    'eGauge1':[noneOption,randomOption,increaseOption,decreaseOption,increaseDecreaseOption,highNumOption],
    'eGauge2':[noneOption,randomOption,increaseOption,decreaseOption,increaseDecreaseOption,highNumOption],
    'eGauge':[noneOption,randomOption,increaseOption,decreaseOption,increaseDecreaseOption,highNumOption],
    'eProgress':[noneOption,randomOption,increaseOption,decreaseOption,increaseDecreaseOption,highNumOption],
    'decoration-9':[noneOption,randomOption,increaseOption,decreaseOption,increaseDecreaseOption,highNumOption],
    'ZdvRatio':[noneOption,randomOption,increaseOption,decreaseOption,increaseDecreaseOption,highNumOption],
    'panel':[noneOption,randomOption,increaseOption,decreaseOption,increaseDecreaseOption,highNumOption],
    'ringSpeed':[noneOption,randomOption,increaseOption,decreaseOption,increaseDecreaseOption,highNumOption],
    'ratioCon':[noneOption,randomOption,increaseOption,decreaseOption,increaseDecreaseOption,highNumOption],
    'piezometer':[noneOption,randomOption,increaseOption,decreaseOption,increaseDecreaseOption,highNumOption],
    'thermometer':[noneOption,randomOption,increaseOption,decreaseOption,increaseDecreaseOption,highNumOption],
    'gradeGauge':[noneOption,randomOption,increaseOption,decreaseOption,increaseDecreaseOption,highNumOption],
    'stageGauge':[noneOption,randomOption,increaseOption,decreaseOption,increaseDecreaseOption,highNumOption],
    'e-lines':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'eBar':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'eBarColor':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'eBarxColor':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'stackedBar':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'peaksBar':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'eLineBars':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'e_graphicBar':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'e_pnBar':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'eBars':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'bar3dcolors':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'stepLine':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'polarBar1':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'polarBar':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'eBarx':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'rankBar':[noneOption,randomBarOption,increaseBarOption,decreaseBarOption,increaseDecreaseBarOption,highBarOption],
    'stackedLine':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'twoYLineBar':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'gatBar':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'eLine-1':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'lineBar':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'avgLine':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'contrastLine':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
    'e_pie':[noneOption,randomPieOption,increasePieOption,decreasePieOption,increaseDecreasePieOption,highPieOption],
    "rose":[noneOption,randomPieOption,increasePieOption,decreasePieOption,increaseDecreasePieOption,highPieOption],
    'ePiePro':[noneOption,randomPieOption,increasePieOption,decreasePieOption,increaseDecreasePieOption,highPieOption],
    'rings':[noneOption,randomPieOption,increasePieOption,decreasePieOption,increaseDecreasePieOption,highPieOption],
    'pie_s1':[noneOption,randomPieOption,increasePieOption,decreasePieOption,increaseDecreasePieOption,highPieOption],
    'eHotMap':[noneOption,randomPieOption,increasePieOption,decreasePieOption,increaseDecreasePieOption,highPieOption],
    'e_ring':[noneOption,randomPieOption,increasePieOption,decreasePieOption,increaseDecreasePieOption,highPieOption],
    'eMwRatio':[noneOption,randomPieOption,increasePieOption,decreasePieOption,increaseDecreasePieOption,highPieOption],
    'wordCloud':[noneOption,randomPieOption,increasePieOption,decreasePieOption,increaseDecreasePieOption,highPieOption],
    'funnel':[noneOption,randomPieOption,increasePieOption,decreasePieOption,increaseDecreasePieOption,highPieOption],
    'scrollRankingBoard':[noneOption,randomPieOption,increasePieOption,decreasePieOption,increaseDecreasePieOption,highPieOption],
    'zdvPieThree':[noneOption,randomPieOption,increasePieOption,decreasePieOption,increaseDecreasePieOption,highPieOption],
    'eRadar':[noneOption,randomRadarOption,increaseRadarOption,decreaseRadarOption,increaseDecreaseRadarOption,highRadarOption],
    'areaMap':[noneOption,randomBubMapOption,increaseBubMapOption,decreaseBubMapOption,increaseDecreaseBubMapOption,highBubMapOption],
    'bubMap':[noneOption,randomBubMapOption,increaseBubMapOption,decreaseBubMapOption,increaseDecreaseBubMapOption,highBubMapOption],
    'bubChainMap':[noneOption,randomBubMapOption,increaseBubMapOption,decreaseBubMapOption,increaseDecreaseBubMapOption,highBubMapOption],
    'e_sunburst':[noneOption,randomTreeOption,increaseTreeOption,decreaseTreeOption,increaseDecreaseTreeOption,highTreeOption],
    'treeMap':[noneOption,randomTreeOption,increaseTreeOption,decreaseTreeOption,increaseDecreaseTreeOption,highTreeOption],
    'Pie11':[noneOption,randomPieOption,increasePieOption,decreasePieOption,increaseDecreasePieOption,highPieOption],
    'RankBarPro':[noneOption,randomPieOption,increasePieOption,decreasePieOption,increaseDecreasePieOption,highPieOption],
    'CubeBar':[noneOption,randomBarOption,increaseBarOption,decreaseBarOption,increaseDecreaseBarOption,highBarOption],
    'pictorialBar':[noneOption,randomLineOption,increaseLineOption,decreaseLineOption,increaseDecreaseLineOption,highLineOption],
}