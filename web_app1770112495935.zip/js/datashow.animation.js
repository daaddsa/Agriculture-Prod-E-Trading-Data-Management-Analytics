var dsAnimationListCommon = [
    {label:'无',value:'none'},
    {label:'旋转',value:'ds-rotate'},
    {label:'摇摆旋转',value:'ds-swingRotate'},
    {label:'闪烁',value:'ds-blink'},
    {label:'脉冲闪烁',value:'ds-pulse'},
]
var dsAnimationListImg = [
    {label:'水平平移',value:'ds-slideHorizontal'},
     {label:'浮动',value:'ds-float'},
    // {label:'环绕移动',value:'ds-moveAround'},
]
var dsAnimationListMask = [
    {label:'水平平移',value:'ds-slideHorizontal'},
     {label:'浮动',value:'ds-float'},
    // {label:'环绕移动',value:'ds-moveAround'},
]